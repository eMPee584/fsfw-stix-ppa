class EndViewer(BaseException):
    pass


class IPCException(Exception):
    pass
